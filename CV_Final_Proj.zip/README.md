# gamestate_CV
Computer vision project to determine the state of a game based on the location of pieces.
